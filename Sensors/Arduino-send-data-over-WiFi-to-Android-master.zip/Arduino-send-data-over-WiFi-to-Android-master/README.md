# Arduino-send-data-over-WiFi-to-Android
Send data from Arduino UNO via ESP8266 over WiFi connection to Android application

view vdo demo at : https://www.youtube.com/watch?v=mpwbigR_R7A
